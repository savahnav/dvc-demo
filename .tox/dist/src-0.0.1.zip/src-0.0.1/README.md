create environment

activate the environment

create requirements.txt file

install the req using pip
pip install -r requirements.txt


git init
dvc init
dvc add data_given/winequality.csv
git add .
````
    staging area
````
git commit -m "first commit"

oneliner updates for readme

````
git add . && git commit -m "update Readme.md"
git remote add origin https://github.com/c17hawke/simple-dvc-demo.git
git branch -M main
git push origin main
````

get_data file creation